/*
 * $Id$
 */

// just for the global definition of Config and Config2
#include "structs.h"

struct SquidConfig Config;

struct SquidConfig2 Config2;
