/*
 * text_backend.h
 *
 * AUTHOR: Flavio Pescuma. <flavio@marasystems.com>
 *
 */
#include "digest_common.h"
extern int LDAPArguments(int argc, char **argv);
extern void LDAPHHA1(RequestData * requestData);
